public class SammyMoto {
    public static void main(String[]args) {
        System.out.println("Sammy’s makes it fun in the sun.");
    }
}
