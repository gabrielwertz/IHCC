import javax.swing.*;
import java.text.DecimalFormat;

class init {

    public static int iMins;
    public static double cMins;
    public static double cHours;
    public static double cCost;
    public static double cMinsCost;
    public static double cTotal;
    public static String oTotal;

    public static void main(String[] Args) {

        input();
        calcs();
        output();
    }

    public static void input() {
        iMins = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Enter the amount of minutes you have rented"));
    }

    public static void calcs() {
        cHours = iMins / 60;
        cMins = iMins % 60;
        cCost = cHours * 40;
        cMinsCost = cMins * 1;
        cTotal = cCost + cMinsCost;

    }


    public static void output() {
        String pattern = "$###,###.##";
        DecimalFormat moneyFormat = new DecimalFormat(pattern);
        oTotal = moneyFormat.format(cTotal);

        System.out.println("sSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsS");
        System.out.println("sS Sammy’s makes it fun in the sun sS");
        System.out.println("sSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsS");
        System.out.println( " you rented for: " + cMins
                + " minutes " + cHours + " hours " + " for a total cost of " + oTotal);

    }
}
