import java.util.Scanner;

class Calcs {

    static int iTotal;
    static double iRate = .45;
    static int cDozen;
    static double cTotalLeftover;
    static int cLeftover;
    static double cTotal;
    static double cCost;
    static Scanner myScanner;

    public static void main(String[] Args) {
        myScanner = new Scanner(System.in);

        System.out.println("Enter number of eggs:");
        iTotal = myScanner.nextInt();
        cLeftover = iTotal % 12;
        cTotalLeftover = cLeftover * iRate;
        cDozen = iTotal / 12;
        cCost = cDozen * 3.25;
        cTotal = cCost + cTotalLeftover;

        System.out.println("You Have: " + iTotal + " eggs");
        System.out.println("That's" + cDozen + " dozen,$3.25 a dozen and " + cLeftover + " loose eggs at $.45 for:$" + cTotal);
    }
}