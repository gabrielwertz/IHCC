public class SammyMoto2 {
    public static void splashbois() {
        System.out.println("sSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsS");
        System.out.println("sS ammy’s makes it fun in the sun sS");
        System.out.println("sSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsS");
    }



}
